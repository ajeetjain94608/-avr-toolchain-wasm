// PR middle-end/66199
// { dg-do run }

#include "../libgomp.c/pr66199-5.c"
